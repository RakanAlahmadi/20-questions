import javax.swing.JFrame;

/**
 * Main class of the program, it also create the window for the image
 * @author Rakan Alahmadi
 *
 */
public class Guess {


	public static void main(String[ ] args)
	{
		AnimalGuess animal = new AnimalGuess();
		animal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		animal.setVisible(true);
		animal.pack();

	}

}
