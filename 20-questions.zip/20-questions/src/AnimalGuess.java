


import java.util.Scanner;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * This class takes care of many things:
 * 1- Creating the tree
 * 2- Running the program
 * 3- Getting the user input for the choices
 * 4- Displaying an image of the animal
 * 
 * @author Rakan Alahmadi
 *
 */
public class AnimalGuess extends JFrame
{

	private ImageIcon image; // to create the image
	private JLabel label;    // to help creating the image

	private  Scanner keyBoard = new Scanner(System.in); //to get the user input

	/**
	 * Default constructor create  tree and starts the game
	 */
	public AnimalGuess(){

		setLayout (new FlowLayout());
		BTNode<String> root;
		instruct( );
		root = smallTree( );
		play(root);
		//----------------------------------------------

	}
	/**
	 * Game instructions
	 */
	private void instruct( )
	{
		System.out.println("Think of an animal. And I will try to figure it out.");

	}

	//---------------------------------------------------------

	/**
	 * This method will take a Node and if is not a leaf it moves either right or left. When it reaches a leaf
	 * it gives a guess to the user  and displays the image
	 * @param current
	 */
	private void play(BTNode<String> current)
	{
		while (!current.isLeaf( ))
		{
			if (userAnswer(current.getData( )))
				current = current.getLeft( );
			else
				current = current.getRight( );
		}
		//----------------------------------------------------------

		System.out.print("My guess is " + current.getData( ) + ". ");

		image = new ImageIcon(getClass().getResource(current.getString()));

		label= new JLabel(image);
		add(label);
	}
	//----------------------------------------------------------
	/**
	 * Creates a tree of five levels, which is going be the tree we use in the game
	 * @return
	 */
	private BTNode<String> smallTree( )   
	{

		BTNode<String> root;
		BTNode<String> child;
		//-----------------------------------------------------
		final String ROOT_QUESTION = "Is it a mammal?";
		final String LEFT_QUESTION = "Does Eat Meat?";
		final String LEFT2_QUESTION = "Is it Domestic?";
		final String LEFT3_QUESTION = "Does Bark?";
		final String RIGHT_QUESTION = "Does it have strips?";
		final String RIGHT1_QUESTION = "Is it from the cat family?";
		final String RIGHT2_QUESTION = "Does it live under water?";
		final String RIGHT3_QUESTION = "Does it fly?";
		//------------------------------------------------------ 

		final String ANIMAL1 = "Dog";
		final String ANIMAL2 = "Cat";
		final String ANIMAL3 = "Fish";
		final String ANIMAL4 = "Bird";
		final String ANIMAL5 = " an Ostrich";
		final String ANIMAL6 = "Tiger";
		final String ANIMAL7 = "Bear";
		final String ANIMAL8 = "Zebra";
		final String ANIMAL9 = "Horse";


		//-----------------------------------------------------
		root = new BTNode<String>(ROOT_QUESTION, null, null,null);

		// Create and attach the left subtree.
		child = new BTNode<String>(LEFT_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(LEFT2_QUESTION, null, null, null));
		child.setRight(new BTNode<String>(RIGHT_QUESTION, null, null,null));
		root.setLeft(child);
		//-----------------------------------------------------
		// Create and attach the left subtree of the left subtree.
		child = new BTNode<String>(LEFT2_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(LEFT3_QUESTION, null, null,null));
		child.setRight(new BTNode<String>(RIGHT1_QUESTION, null, null,null));
		root.getLeft().setLeft(child);
		//-----------------------------------------------------
		//Create and attach the left subtree of the left subtree of the left subtree
		child = new BTNode<String>(LEFT3_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(ANIMAL1, null, null,"/pics/Dog.jpg"));
		child.setRight(new BTNode<String>(ANIMAL2, null, null,"/pics/Cat.jpg"));
		root.getLeft().getLeft().setLeft(child);
		//-------------------------------------------------------
		//Create and attach the right subtree of the left subtree of the left subtree
		child = new BTNode<String>(RIGHT1_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(ANIMAL6, null, null,"/pics/Tiger.jpg"));
		child.setRight(new BTNode<String>(ANIMAL7, null, null,"/pics/Bear.jpg"));
		root.getLeft().getLeft().setRight(child);
		//---------------------------------------------------------
		child = new BTNode<String>(RIGHT_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(ANIMAL8, null, null,"/pics/Zebra.jpg"));
		child.setRight(new BTNode<String>(ANIMAL9, null, null,"/pics/Horse.jpg"));
		root.getLeft().setRight(child);
		//-----------------------------------------------------------
		child = new BTNode<String>(RIGHT2_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(ANIMAL3, null, null,"/pics/Fish.jpg"));
		child.setRight(new BTNode<String>(RIGHT3_QUESTION, null, null,null));
		root.setRight(child);
		//------------------------------------------------------------
		child = new BTNode<String>(RIGHT3_QUESTION, null, null,null);
		child.setLeft(new BTNode<String>(ANIMAL4, null, null,"/pics/Bird.jpg"));
		child.setRight(new BTNode<String>(ANIMAL5, null, null,"/pics/Ostrich.jpg"));
		root.getRight().setRight(child);


		return root;
	}
	//---------------------------------------------------------
	/**
	 * This method gets the user input and returns true if the choice starts with Y and 
	 * false if the choice starts with N 
	 * @param someString
	 * @return
	 */
	private boolean userAnswer(String someString)
	{
		String answer;

		System.out.print(someString + " (Yes or No) : ");

		answer = keyBoard.nextLine( ).toUpperCase( );

		while (!answer.startsWith("Y") && !answer.startsWith("N"))
		{
			System.out.print("Invalid response. Please type Y or N: ");

			answer = keyBoard.nextLine( ).toUpperCase( );
		}

		return answer.startsWith("Y");
	}


	//---------------------------------------------------------------

}



