
import java.util.*;
/**
 * 
 * @author Rakan Alahmadi
 * This Class help creating the nodes in the tree. Each note should have data, and most of them will have children nodes.
 * Also in this Class we will be able to count how many nodes we have in a tree and the height of the tree.
 * 
 *
 * @param <T>
 */
public class BTNode<T> {

	private T data;    // This data will be the either a question given, or an animal    
	private BTNode<T> left, right; // These are the right Node and the Left Node
	private String name; // this holds the source of the image

	/**
	 * Default constructor 
	 */
	public BTNode() { 
	}



	/**
	 *  constructer that sets "someData" to "data"
	 * @param SomeData
	 */
	public BTNode(T someData, String someString) {  
		this(someData, null, null,someString );
	}

	/**
	 * a constructer that takes three peramiters and set them to local variables Data,Left and Right
	 * @param someData
	 * @param someNodeL
	 * @param someNodeR
	 * @param someString
	 */
	public BTNode(T someData, BTNode<T> someNodeL, BTNode<T> someNodeR, String someString) {  
	data = someData;
	left = someNodeL;
	right = someNodeR;
	name = someString;
	}


	/**
	 * These three methods returns the Data, the left and the right
	 * @return
	 */
	public T getData(){ 
		return data; 
	}
	public BTNode<T> getLeft(){ 
		return left; 
	}
	public BTNode<T> getRight(){
		return right;
	}
	public String getString(){
		return name;
	}


	/**
	 * This method receives "someData" and then set it to "data"
	 * @param someData
	 */
	public void setData(T someData) {
	data = someData;
	}
	/**
	 * This method takes a "someNode" and set it to "left"
	 * @param l
	 */
	public void setLeft(BTNode<T> someNode)   { 
	left = someNode;
	}
	/**
	 * This method takes a "someNode" and set it to "Right"
	 * @param r
	 */
	public void setRight(BTNode<T> someNode)  { 
	right = someNode;
	}

	/**
	 * This method checks if the node is a leaf or not and that would mean the if the node does not have right nor left child
	 * @return
	 */
	public boolean isLeaf(){
		return (left == null) && (right == null);
	}
}


